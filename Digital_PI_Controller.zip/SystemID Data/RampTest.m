

% Load the CSV file
data = readtable('ServoMotorData.xlsx', 'Range', 'A2:E462');
data(1,:) = []; % Deletes the first row


% Extract variables using column headings
time = data.TIME_s_; 
setpoint = data.r_t__SetPoint;
velocity = data.MotorVelocity;

time = str2double(time);
setpoint = str2double(setpoint);
velocity = str2double(velocity);


% Plot the data
figure;
plot(time, setpoint, 'r', 'LineWidth', 2); % Plot Set Point in Red
hold on;
plot(time, velocity, 'b', 'LineWidth', 1); % Plot Velocity in Blue
hold off;

% Add labels and legend
xlabel('Time (s)');
ylabel('Value');
title('Set Point and Motor Velocity vs Time');
legend('Set Point', 'Motor Velocity');
grid on;
