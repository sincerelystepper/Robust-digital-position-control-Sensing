% Load the CSV file
data = readtable('C:\Users\Sincerely Stepper\Desktop\EEE4118_Controls Engineering\Project\SystemID Data\Controls Lab\Controls Lab\ServoMotorData -Step Response.CSV');

% Convert columns to numeric values
time = data{:, 1};        % First column: Time
velocity = data{:, 4};    % Fourth column: Output (Motor Velocity)
setpoint = data{:, 3};    % Third column: Setpoint

s = tf('s');

% First-order term for steep initial rise
tau1 = 1.3;  % Adjust for steepness; Ideally tau is 1, but if we make it lower, stepness becomes perfect
A = 4.9;   % Scaling factor to match initial rise

% Second-order term for smoothing
omega_n = 1; % Ensures time constant matches 1s
zeta = 1.3;  % Adjust for smooth rise
B = 1.5;     % Scaling factor to match steady-state

% Combined model
% Tf_combined = (A / (tau1 * s + 1)) + (B / (s^2 + 2*zeta*omega_n*s + omega_n^2));
Tf_combined = (A/(tau1 * s + 1));

% Simulate step response
[y_sim, t_sim] = step(Tf_combined*0.6, time);


% Plot real system data
figure;
plot(time, setpoint, 'r--', 'LineWidth', 2); % Setpoint (dashed red)
hold on;
plot(time, velocity, 'b', 'LineWidth', 2); % Real motor velocity (blue)

% Plot simulated response
plot(t_sim, y_sim, 'g', 'LineWidth', 0.8); % Simulated response (green)

% Formatting
xlabel('Time (s)');
ylabel('Velocity');
title('Comparison of Real and Simulated Step Response');
legend('Set Point', 'Motor Velocity (Real)', 'Simulated Response');
grid on;
hold off;
