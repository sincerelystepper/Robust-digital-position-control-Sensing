% Define the simulated transfer function
s = tf('s');
T_simulated = 5 / (s + 1.3);  % Your given TF

% Frequency range for Bode plot (same as your real data points)
w = [0.2, 0.5, 0.8, 1, 2, 5];  % Frequencies in Hz
% w = 2 * pi * frequencies; % Convert to rad/s for Bode analysis

% Compute the magnitude response of the simulated TF in dB
[mag, ~] = bode(T_simulated, w);
mag_db_simulated = 20 * log10(squeeze(mag)); % Convert magnitude to dB

% Real system measured data
magnitude_db_real = [19, 18.53, 18.53, 17.31, 15.53, 12.77]; % Real system magnitude in dB

% Plot real system data
figure;
semilogx(frequencies, magnitude_db_real, 'o-', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Real Data');
hold on;

% Plot simulated system Bode magnitude
semilogx(frequencies, mag_db_simulated, 's-', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Simulated TF (5/(s+1.3))');

% Labels and title
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title('Bode Magnitude Plot: Simulated vs Real System');
legend;
grid on;
hold off;
