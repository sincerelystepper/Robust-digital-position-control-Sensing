# System Identification Process Analysis

## Step 1: Ramp Test & Determining System Limits

The system identification begins with a ramp test, applying an input of $r(t) = b + a(t) = -2 + 0.1t$ to characterize the system's fundamental properties.

[INSERT FIGURE 1: Servo Motor Velocity and Input Signal with Range Limits]
![[Figure 1.png]]
From Figure 1 ("Servo Motor Velocity and Input Signal with Range Limits"), two critical boundary conditions are identified:

1. **DAC Limits**: The Digital-to-Analog Converter saturates at approximately -10 and 10 volts, which defines the acceptable input range.
    
2. **Deadband Region**: Between input values of -0.24 and 0.35, the motor output is effectively zero. This deadband is an inherent property of the motor system where the input signal is insufficient to overcome static friction and other mechanical resistances.
    

Based on these observed limits, a step size of $B = 0.6$ was selected to satisfy the constraint: $$0.35 < B < 1.33$$

This ensures the input is above the deadband threshold but within the DAC's operational range.

The primary reason for conducting the ramp test is to identify these system limits before proceeding with more detailed modeling. A normal ramp response would show a straight line, but the actual response reveals both saturation limits and the deadband region which are critical characteristics of this motor system.

## Step 2: Step Test & First-Order Model Derivation

After determining appropriate input ranges from the ramp test, a step input of magnitude $B = 0.6$ was applied to the system. The goal was to identify the parameters of a first-order transfer function model:

$$P(s) = \frac{A}{1 + s\tau}$$

[INSERT FIGURE 2: Servo Motor Step Response - Raw Data]
![[Figure 2.png]]

Figure 2 shows the raw step response data of the system when subjected to the step input. The response exhibits the classic shape of a first-order system with some additional dynamics.

[INSERT FIGURE 3: Step Response with Steady-State Value Line (AB = 2.99)]
![[Figure 3.png]]

Figure 3 illustrates the steady-state value analysis, where:

- Final steady-state value: $y_f = 2.96$
- Initial value: $y_i = 0.03$
- The product $AB = y_f - y_i = 2.93$
- With $B = 0.6$, the gain parameter $A = \frac{AB}{B} = \frac{2.93}{0.6} = 4.88$

The time constant $\tau$ was determined by finding when the response reaches 63.2% of its final value. This percentage comes from the fact that a first-order system reaches approximately 63.2% (or $1-e^{-1}$) of its final value after one time constant.

- Target value: $y(\tau) = y_i + 0.632 \times (y_f - y_i) = 0.03 + 0.632 \times 2.93 = 1.89$
- Using linear interpolation between data points at $t = 0.8s$ (where $y = 1.825$) and $t = 0.9s$ (where $y = 1.914$)
- Calculated $\tau = 0.873$ seconds

$$\tau = 0.8 + \frac{1.89 - 1.825}{1.914 - 1.825} \times 0.1 = 0.8 + 0.073 = 0.873 \text{ seconds}$$

Therefore, the first-order model derived from this step test is:

$$P(s) = \frac{4.88}{1 + 0.873s}$$

## Step 3: Model Refinement

[INSERT FIGURE 4: Comparison of Experimental and First-Order Model (τ = 0.87s)]
![[Figure 4.png]]

Figure 4 compares the experimental step response data with the simulated response of the first-order model using $\tau = 0.87s$. The comparison reveals an important insight: the real system exhibits underdamped behavior that isn't fully captured by the initial first-order model.

This discrepancy exists because we are using a first-order transfer function to approximate what is actually a second-order physical system (the motor). The transient portion of the response, particularly the damping characteristics, shows that the actual system has more complex dynamics.

To better approximate the underdamped response while maintaining reasonable rise time characteristics, the time constant was adjusted to $\tau = 1.3$ seconds, yielding the refined model:

$$P(s) = \frac{4.93}{1 + 1.3s}$$

![[Pasted image 20250309083701.png]]
This adjustment sacrifices some accuracy in the initial rise time to better capture the overall dynamic behavior. The trade-off is acceptable because the model will be used for control system design where the overall response pattern is more important than perfectly matching the initial transient.

## Step 4: Determining the Integrator Scalar 'a'

[INSERT FIGURE 5: Position Output]
![[Figure 5.png]]

Figure 5 ("Position Output") shows the raw position data as the system responds to various inputs. The plot shows ramp transitions between approximately -10 and 10 volts. The sudden drops in the signal (where the output rapidly drops from around +10 to -10) represent system resets or wraparounds and are not relevant to the parameter estimation. We are only interested in the gradient of the ramps from -10 to 10, which represents the system's integrating behavior.
![[Figure 5.1.png]]

[INSERT FIGURE 6: Position Output with Linear Approximation (a = _)]

Figure 6 ("Position Output with Linear Approximation") shows these ramp portions with a fitted line representing a gradient of approximately _. This gradient represents how quickly the output position changes in response to a constant input.

By calculating the relationship between this gradient and the known motor speed:

- Average gradient measured: approximately __
- Motor speed: 2.969
- Integrator scalar: $a = \frac{\text{gradient}}{\text{motor speed}} =$

This scalar 'a' represents how the motor velocity translates to position changes over time, which is essential for modeling the complete electromechanical system.

## Step 5: Frequency Response Analysis (Bode Plot)

[INSERT FIGURE 7: Bode Plot of simulated System]
![[Figure 7.png]]

Figure 7 shows the theoretical Bode plot of the simulated system based on the first-order model. For a first-order system, we expect:

- Magnitude response: constant at low frequencies, then rolling off at -20 dB/decade after the critical frequency $\omega_c = \frac{1}{\tau}$
- Phase response: starting at 0° for low frequencies and approaching -90° at high frequencies

[INSERT FIGURE 8: Bode Plot of System from Raw Data]

The experimental Bode plot (Figure 8) was generated by:
1. Applying sinusoidal inputs at various frequencies around the critical frequency $\omega_c = \frac{1}{\tau}$
2. For each frequency:
    - Input: $y_{in} = A\cos(\omega t)$
    - Output: $y_{out} = A'\cos(\omega t + \phi)$
    - Gain calculation: $\text{Gain}_{\text{dB}} = 20\log_{10}\frac{A'}{A}$
    - Phase calculation: $\phi = \frac{\Delta t}{T} \times 360°$ (using peak-to-peak method)

[INSERT FIGURE 9: Bode Plot Comparison - Raw vs Simulated]
![[Figure 9.jpeg]]
Figure 9 compares the theoretical and experimental Bode plots. The close match validates the first-order model structure, with slight deviations at lower frequencies where signal quality typically deteriorates. These deviations are expected as low-frequency measurements are more time-consuming and susceptible to drift and other disturbances.

## Step 6: System with Brake Disk

The second phase of the system identification involved characterizing the system with a brake disk applied, which introduces additional mechanical resistance.

[INSERT FIGURE 10: Raw Motor Response with Braking Applied]
![[Figure 10.png]]

Figure 10 shows the raw step response of the system with braking applied. Compared to the original system, the response is noticeably different both in terms of amplitude and dynamics.

[INSERT FIGURE 11: Braking Response with Steady-State Value Line (AB = 0.5146)]
![[Figure 11.png]]
Figure 11 illustrates the steady-state value analysis for the braking system:

- Steady-state value: $AB = 0.5146$
- With $B = 0.6$, the gain parameter $A = \frac{0.5146}{0.6} = 0.858$

For the time constant determination:

- Target value at 63.2%: $y(\tau) = 0.5146 \times 0.632 = 0.325$
- Through interpolation between time points 0.2s and 0.3s, where the response values were 0.267 and 0.326 respectively
- Initial time constant estimate: $\tau = 0.4$ seconds

[INSERT FIGURE 12: Comparison of Simulated vs Raw Motor Response with Braking Applied (τ = 0.4 s)]
![[Figure 12.png]]

Figure 12 compares the experimental data with the simulated model using $\tau = 0.4s$. Based on this comparison, the time constant was further refined to $\tau = 0.5s$ for an optimized model as shown in Figure 13.

[INSERT FIGURE 13: Comparison of Experimental and Adjusted First-Order Model (τ = 0.5 s)]
![[Figure 13.png]]
The final braking system model is: $$P_b(s) = \frac{0.858}{1 + 0.5s}$$

[INSERT FIGURE 14: Comparison of First-Order(Simulated) Models: Original vs. Braking System]
![[Figure 14.png]]
Figure 14 compares the step responses of the original system model and the braking system model. Two significant differences are observed:

1. **Gain Reduction**: The braking system's steady-state value (0.51) is significantly lower than the original (2.99). This is physically intuitive as the brake increases friction, requiring more input torque to achieve the same output velocity.
    
2. **Faster Response**: The braking system has a rise time of approximately 1.1s (calculated as $2.2\tau = 2.2 \times 0.5 = 1.1s$), compared to 2.86s for the original system ($2.2\tau = 2.2 \times 1.3 = 2.86s$). This faster response occurs because the increased damping reduces the mechanical inertia's effect, allowing quicker changes in velocity.
    

## Step 7: System with Mass Disk

The third configuration involved adding an inertial mass disk to the system, which would be expected to increase the system's inertia and alter its dynamic properties.

[INSERT FIGURE 15: Servo Motor Response with Added Inertial Mass]
![[Figure 15.png]]
Figure 15 shows the raw step response of the system with the added mass disk. As expected, the system exhibits slower dynamics but with higher ultimate gain.

[INSERT FIGURE 16: Mass-Loaded System with Steady-State Value Line (AB = 4.5179)]
![[Figure 16.png]]
Figure 16 presents the steady-state value analysis:

- Steady-state value: $AB = 4.5179$
- With $B = 0.6$, the gain parameter $A = \frac{4.5179}{0.6} = 7.53$

For the time constant determination:

- Target value at 63.2%: $y(\tau) = 4.5179 \times 0.632 = 2.855$
- Through interpolation between time points 7.9s and 8.0s, where the response values were 2.851 and 2.861 respectively
- Initial time constant estimate: $\tau = 7.9$ seconds

[INSERT FIGURE 17: Mass-Loaded System: Experimental vs. First-Order Model (τ = 7.9s)]
![[Figure 17.png]]

Figure 17 compares the experimental data with the simulated response using $\tau = 7.9s$. The simulation showed that the transient response, particularly the rise time, was slightly too slow (the simulated response had a less steep slope than the actual system).

[INSERT FIGURE 18: Mass-Loaded System: Experimental vs. Optimized Model (τ = 6s)]
![[Figure 18.png]]

To better match the transient behavior, the time constant was adjusted to $\tau = 6s$ as shown in Figure 18. This adjustment provides a better fit to the experimental data, particularly during the critical rising portion of the step response.

The final mass-loaded system model is: $$P_m(s) = \frac{7.04}{1 + 6s}$$

[INSERT FIGURE 19: Comparison of First-Order Models: Original vs. Mass-Loaded System]
![[Figure 19.png]]
Figure 19 compares the step responses of the original system and the mass-loaded system, revealing two important contrasts:

1. **Increased Gain**: The mass-loaded system's steady-state value (4.52) is higher than the original (2.99). This might seem counterintuitive but can be explained by the mass disk's momentum conservation properties, which can amplify the steady-state response for a given input.
    
2. **Slower Response**: The mass-loaded system has a much longer rise time of approximately 13.2s (calculated as $2.2\tau = 2.2 \times 6 = 13.2s$), compared to 2.86s for the original system. This dramatic slowing is expected as the additional inertia requires more time to accelerate to its final velocity.
    

## Parameter Variation Analysis

[INSERT FIGURE 20: Step Response Comparison: Standard, Braking, and Mass-Loaded Systems]
![[Figure 20.png]]

Figure 20 provides a comprehensive comparison of all three system configurations (standard, braking, and mass-loaded), highlighting the significant parameter variations that would need to be accounted for in robust control design.

The identified parameter ranges across the different configurations are:

**Gain parameter A:**

- Nominal (standard system): 4.93
- Minimum (with braking): 0.858
- Maximum (with added mass): 7.04

**Time constant τ:**

- Nominal (standard system): 1.3s
- Minimum (with braking): 0.4s
- Maximum (with added mass): 6s

These variations demonstrate how physical modifications to the system dramatically alter both gain and time constant:

- **Braking System**: The increased friction reduces the gain (more input required for less output) and speeds up the system (smaller τ) by adding damping that reduces the effective inertia.
    
- **Mass-Loaded System**: The additional inertia increases the gain (momentum conservation amplifies steady-state response) but significantly slows the system (larger τ) due to the increased mass that must be accelerated.
    

This parameter variation analysis provides essential information for designing a control system that must maintain stability and performance across all operating conditions. The controller would need to accommodate:

1. A gain variation of approximately 8.2:1 (7.04/0.858)
2. A time constant variation of 15:1 (6/0.4)

These wide ranges present a significant challenge for robust control design, potentially requiring adaptive or gain-scheduled approaches to maintain consistent performance across all configurations.